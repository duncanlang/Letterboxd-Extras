# letterboxd-extras
 
An add-on for FireFox that adds some additional features.

# Features
- Pulls movie scores from IMDb, Rotten Tomatoes, Metacritic, and CinemaScore (if available)
- Adds links to Rotten Tomatoes and BoxOfficeMojo
- Adds film rating, next to the year
- Adds the full US release on hover of the release year
- Adds budget and box office numbers to the details tab (if available)
